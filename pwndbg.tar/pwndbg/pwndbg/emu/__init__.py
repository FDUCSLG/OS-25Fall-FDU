"""
Emulation assistance from Unicorn.
"""
